#include<stdio.h>
#include<conio.h>
void main()
{
printf("name:- thummar abhi v \n");
printf("age:- 12 \n");
printf("school:- tapan\n");
}
