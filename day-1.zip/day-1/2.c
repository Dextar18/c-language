#include<stdio.h>
#include<conio.h>
void main()
{
printf("----------------- \n");
printf("I       | \n");
printf("R       |\n");
printf("N       | \n");
printf("W       |\n");
printf("I       | \n");
printf("----------------- \n");
}
